package com.projectvehicle;

public class Utils {
    public static String SHREF="MB";
}
