package com.projectvehicle.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.projectvehicle.R;

public class GetAllCarsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_all_cars);
    }
}